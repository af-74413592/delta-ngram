import pathlib,json,subprocess,os
from datetime import datetime,timezone
r=pathlib.Path(__file__).parent;l=json.loads((r/'launch.json').read_text());env=os.environ.copy();env.update(l['environment'])
with (r/'launch.log').open('w') as f:
 p=subprocess.Popen(l['command'],cwd=l['cwd'],env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
 (r/'child.json').write_text(json.dumps({'pid':p.pid,'started_utc':datetime.now(timezone.utc).isoformat()}))
 rc=p.wait()
(r/'exit.json').write_text(json.dumps({'returncode':rc,'exited_utc':datetime.now(timezone.utc).isoformat()}))
