import json,pathlib,subprocess,os
r=pathlib.Path(__file__).parent
s=json.loads((r/'spec.json').read_text());env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=s['repo']+'/src:'+s['repo']+'/scripts/native_qwen38')
with (r/'validation.log').open('w') as f: result=subprocess.run([s['python'],*s['args'],'--validate'],env=env,cwd=s['repo'],stdout=f,stderr=subprocess.STDOUT)
(r/'validation.exitcode').write_text(str(result.returncode))
