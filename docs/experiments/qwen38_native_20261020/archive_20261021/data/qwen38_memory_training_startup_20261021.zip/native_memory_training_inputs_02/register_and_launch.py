from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,time,os,traceback
r=Path(__file__).resolve().parent
def write(name,value):
 p=r/name;t=p.with_suffix(p.suffix+'.partial');t.write_text(json.dumps(value,indent=2));os.replace(t,p)
def now():return datetime.now(timezone.utc).isoformat()
try:
 write('registration_status.json',{'status':'waiting_for_CPU_validation','time':now()})
 for i in range(120):
  if all((r/(b+'_validation.exitcode')).exists() for b in ['residual','full']):break
  time.sleep(5)
 else:raise RuntimeError('CPU validation timeout; no launch')
 vals={b:json.loads((r/(b+'_validation.log')).read_text()) for b in ['residual','full']}
 assert all((r/(b+'_validation.exitcode')).read_text().strip()=='0' for b in vals)
 assert all(v['status']=='memory_fork_CPU_valid' for v in vals.values())
 hashes={v['manifest']['code_manifest_sha256'] for v in vals.values()};assert len(hashes)==1
 decision={'protocol':'qwen38_memory_training_registration_v2','status':'registered_for_execution','registered_utc':now(),
  'user_authorization':'Direct execution; residual first, then full; endpoint DEV64 twice per branch; no further perturbation gate',
  'order':['residual','full'],'GPU_count_per_branch':4,'complete_groups_per_branch':835,'additional_targets_per_branch':20015113,
  'endpoint_DEV64_runs_per_branch':2,'same_immutable_terminal_checkpoint':True,
  'residual_difference_baseline':'matched_base','residual_evidence':'All 12 empty-state blocks: matched difference exactly zero; old difference entirely batch/lane effect. Nonempty writer-feature noise/signal median 0.3194, max 0.4306.',
  'supplemental_output':'/workspace/delta-ngram-memory-fork-20261021/reports/native_memory_supplemental_probe_01',
  'supplemental_report_sha256':'031f55fb23e6a616ca8a2e6cd0b3b6a5b076a0e064c9bb8c45ab361d832561ab',
  'training_code_manifest_sha256':next(iter(hashes)),
  'diagnostic_G_action':'monitor_only_never_automatic_stop',
  'independent_repeat_NLL_status':'pending_repeat_only_control; not a training gate; V2 perturbation scores are not repeat scores',
  'first_group_loss_check':'residual zero head asserted; compare actual loss_sum and mean_nll float.hex against mainline3338; log difference without claiming guaranteed identity',
  'automatic_retry':False,'FINAL_used':False}
 write('training_decision.json',decision)
 with (r/'supervisor_bootstrap.claim').open('x') as f:f.write(now())
 with (r/'pair_supervisor.log').open('w') as f:
  child=subprocess.Popen(['/workspace/venvs/qwen38-swift/bin/python',str(r/'pair_supervisor.py')],cwd=r,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 write('registration_status.json',{'status':'supervisor_started','time':now(),'pid':child.pid})
except BaseException as e:
 write('registration_status.json',{'status':'failed','time':now(),'error':str(e),'traceback':traceback.format_exc()});raise
