import os,subprocess,json,pathlib
r=pathlib.Path(__file__).parent;s=json.loads((r/'spec.json').read_text());env=dict(os.environ);env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=s['repo']+'/src:'+s['repo']+'/scripts/native_qwen38')
with (r/'validation.log').open('w') as f:p=subprocess.run([s['python'],*s['args'],'--validate'],cwd=s['repo'],env=env,stdout=f,stderr=subprocess.STDOUT)
(r/'validation.exitcode').write_text(str(p.returncode))
